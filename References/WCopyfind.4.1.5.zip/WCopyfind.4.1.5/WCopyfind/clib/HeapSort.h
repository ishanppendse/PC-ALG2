	void HeapSort(unsigned long *tableA,int *tableB,int n);
